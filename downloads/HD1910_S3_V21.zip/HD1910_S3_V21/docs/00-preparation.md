# 0 · 认识器材与准备软件

[教程首页](../README.md) · 下一章：[设置舵机 ID](01-servo-id.md)

## 先认识三个词

- **舵机**：收到角度指令后转动的电机。本项目用能读取位置的三线 TTL 总线舵机，不是普通 PWM 舵机。
- **ESP32-S3**：运行机器人程序的小电脑。烧录就是把程序写进它。
- **IMU**：测量加速度和角速度的传感器，帮助判断底座是否倾倒；本项目用 BMI270。

## 每组准备什么

| 器材 | 数量 | 怎么辨认/用来干什么 |
| --- | --- | --- |
| ESP32-S3 **N16R8** 开发板 | 1 | 16MB Flash、8MB PSRAM；原机为双 Type-C、带 CH340 的板型 |
| HD-1910-C001 / HD1910M 总线舵机 | 2 | FD 中可能显示 HDS1910；须匹配本项目协议 |
| Waveshare **Bus Servo Adapter (A)** | 1 | 有 Type-C、DC/电源端子、舵机口、A/B 跳线帽 |
| BMI270 模块 | 1 | 带 `3.3V/3V3、GND、SCL、SDA` 标字，本项目地址 0x68 |
| 面包板 | 1～2 | 一块放 ESP32，一块可固定 IMU；太窄时两块并排 |
| 原装三芯舵机线 | 按套件 | 微雪与两颗舵机连接，插头和针序要匹配 |
| 杜邦线 | 至少 7 根 | IMU 4 根，微雪信号 3 根，公/母头按针脚选择 |
| USB **数据线** | 1～2 根 | 能传数据的 USB-A/C → Type-C；纯充电线不能通信 |
| 独立稳压 5V 电源 | 1 路 | 由组织者预检；不从 ESP32 取舵机电流 |
| 12V 适配器 + 降压板（若选此方案） | 各 1 | 12V 只进降压板，固定 5V 输出再接微雪 |
| 底座、中间支架、顶部长杆 | 各 1 | [STL 文件](../mechanical/stl/)单位 mm，100% 打印 |
| 舵盘、合适螺钉、绑带、双面胶 | 若干 | 紧固结构与固定底座上的 IMU |
| 万用表 | 每活动台至少 1 | 由组织者检查最终 5V 输出、极性和通断 |

电源容量应按双舵机启动/负载选择，本活动以**稳压 5V、至少 3A 额定输出**作为准备起点；额定电流不保证实际不压降，须由组织者带载检查。不要故意堵转验证。

## 看实物：认识微雪板与舵机

![微雪 Bus Servo Adapter A 厂商实物图，六类接口带数字标注](images/adapter-ports.webp)

*图源：[微雪官方接口说明](https://docs.waveshare.net/Bus_Servo_Adapter_A/)。先找到实物上的同名丝印，再接线；不同批次布局可能有差异。*

| 图中编号 | 这是什么 | 本项目怎么用 |
| --- | --- | --- |
| ① | 圆形 DC 电源口 | 舵机电源入口之一；本项目只输入已确认的稳压 5V |
| ② | 绿色电源端子 | 另一电源入口，`DC+` 接 5V 正极，`DC−` 接负极；与①二选一 |
| ③ | USB-C | 改 ID 时接电脑；运行时拔掉，改走 UART |
| ④ | 两个黄色跳线帽 | 改 ID 都在 B；ESP32 运行都在 A |
| ⑤ | 白色三芯舵机口 | 接原装舵机线；图中丝印为 D / V / G |
| ⑥ | UART 三针 | TX→ESP32 的 17、RX→18、GND→GND |

**照片里板子印着 `DC 9–12.6V`，不是本机器的供电要求。HD1910 本套接法仍用稳压 5V；这块板不会自动把 12V 降成 5V。**

<p align="center"><img src="images/hd1910-vendor.webp" width="340" alt="飞特官方 HD1910M 舵机实物图，可见外壳型号与双插座"></p>

*图源：[飞特 HD-1910-C001 官方资料](https://ftservo.github.io/ftservo-wiki/en/products/models/hd-1910-c001/main/)。先核对外壳型号。图中的“ID”印字不是已设置好的 ID1/ID2；编号需要在 FD 中读取和设置。*

## 三类线，别混淆

| 线 | 接在哪里 | 作用 |
| --- | --- | --- |
| USB 数据线 | 电脑 ↔ 微雪（改 ID），电脑 ↔ ESP32（运行） | 控制板供电与数据 |
| 原装三芯舵机线 | 微雪 ↔ 舵机 ↔ 另一舵机 | V/电源、G/地、D/数据 |
| 杜邦线 | ESP32 ↔ IMU/微雪信号针脚 | 低功率信号和参考地 |

三芯插头的颜色不是针脚标准。即使看到红、黑、黄，也要按舵机和板子的 `V/G/D` 丝印核对。转接线只换插头，不降压、不完成半双工转换。

## Windows 上要装哪些软件

1. **飞特 FD 1.9.8.3**：搜索舵机、改 ID、读状态。用[飞特官方下载页](https://www.feetechrc.com/software.html)提供的 FD，解压后启动 FD 程序。活动组织者可提前安装；本仓库不再分发第三方 EXE。
2. **Python 3.12 或 3.13，64 位**：运行窗口和烧录工具。到 [Python 官方 Windows 下载页](https://www.python.org/downloads/windows/)安装，勾选 **Add python.exe to PATH**，使用默认安装，保留 Tcl/Tk。
3. **USB 串口驱动**：原机器 ESP32 的 UART/COM 口是 CH340；微雪板依实际 USB 芯片安装相应驱动。到板商/芯片厂商官方渠道下载，不随意混装。
4. **Arduino IDE 2（可选）**：[官方下载](https://www.arduino.cc/en/software)。现成固件不需要它；新机器修改零位、重新编译时需要，见[第 4 章](04-flashing.md)。

## 在哪里看 COM 口

1. 右键 Windows 开始按钮 → **设备管理器**，展开 **端口（COM 和 LPT）**。
2. 拔下 USB，看哪项消失；插回，看哪项出现。记下如 `COM7` 的号码。
3. 改 ID 时记微雪的 COM；运行时记 ESP32 的 COM。换电脑可能改变。
4. 没有端口或有黄色感叹号：先换已知能传数据的线，再检查驱动。`COM3` 只是教程示例。

## 下载项目并安装电脑端

1. 在[首页](../README.md)点击 Code → Download ZIP，**全部解压**。
2. 打开解压后的目录，能看到 `00_setup.cmd` 和 `README.md`。
3. 双击 `00_setup.cmd`，等黑色窗口显示 `Setup OK` 再按任意键关闭。
4. 它会创建 `.venv` 并安装 pyserial 3.5、esptool 4.9.0。不要从别的电脑复制 `.venv`。

**完成标志：** 电脑识别相应 COM 口，首次设置显示 `Setup OK`。

参考：[微雪接线](https://docs.waveshare.net/Bus_Servo_Adapter_A/Product-Wiring-Example/)、[飞特 FD 使用说明](https://ftservo.github.io/ftservo-wiki/en/tools/fd/)、[HD-1910-C001 规格](https://ftservo.github.io/ftservo-wiki/en/products/models/hd-1910-c001/main/)。
